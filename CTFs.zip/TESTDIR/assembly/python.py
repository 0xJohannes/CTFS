def giveval():
    k = 0
    i = int("0x28", 16)
    s = int("0x8f", 16)
    while True:
        k+=1
        if hex(i)=="0x8f90":
            return k
            break
        i += s
# print giveval()
def possible():
    i=0
    while i < int("0x8f90", 16):
        f = int("0x6", 16)
        if ((int("0x8f90", 16)-i) % int("0x8f", 16))==0:
            # print int("0x8f90", 16)-i
            # print int("0x8f", 16)
            for q in range(0,(int("0x8f90", 16)-i)/int("0x8f", 16)):
                f += int("0x1", 16)
            print hex(f)
        i+=1
possible();
# for q in range(0,257):
#     f += int("0x1", 16)
# print hex(f)
# f = int("0x6", 16)
# for q in range(0,256):
#     f += int("0x1", 16)
# print f
# print hex(f)
