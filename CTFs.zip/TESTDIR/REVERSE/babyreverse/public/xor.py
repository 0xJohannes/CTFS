import string
from string import ascii_lowercase
strcp="261838221c060d0a"
strcamp="7d 5c 46 06 0d 0a 39 2d 17 13 13 17 01 1a 07 09 38 2b 07 01 43 57 39 2d 17 1c 26 2c 1a 36 2c 42 59 1c 2b 39 0f 36 26 18 38 22 1c 06 0d 0a"
def xor(a,b):
    return ''.join([hex(ord(a[i%len(a)]) ^ ord(b[i%(len(b))]))[2:] for i in range(max(len(a), len(b)))])
strarr=strcamp.split( )
print len(strarr)
# for q in range(len(string.printable)-1):
current = 'f'
iter = len(strarr)-1
result = 'f'
while True and iter > 0:
    rep = 0
    for i in string.printable:
        rep+=1
        if len(xor(i,current))==1:
            # print "0"+xor(i,current)+"----------"+strarr[iter]
            if ("0"+xor(i,current))==strarr[iter]:
                result=result + i
                current = i
                iter -= 1
                print "Found one more char ------ "+result
                rep=0
        else:
            # print xor(i,current)+"----------"+strarr[iter]
            if xor(i,current)==strarr[iter]:
                result=result+i
                current = i
                iter -= 1
                print "Found one more char -------- "+result
                rep=0
    if len(result) >= len(strarr):
        print result
        break


# print xor('|','`')
# payload= result
# res=""
# for i in range(len(payload)):
#     if  i > 0:
#         # print payload[len(payload)-i]+"---------"+payload[len(payload)-i-1]
#         if len(xor(payload[len(payload)-i],payload[len(payload)-i-1]))==1:
#             res+="0"+xor(payload[len(payload)-i],payload[len(payload)-i-1])
#         else:
#             res+=xor(payload[len(payload)-i],payload[len(payload)-i-1])
# print res
# print strcp
