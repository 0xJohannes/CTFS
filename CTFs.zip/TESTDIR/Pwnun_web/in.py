# import urllib2
# for i in range(100,1000):
#     f =  urllib2.urlopen("http://login3.uni.hctf.fun/?passwd={}".format(i))
#     print f.read()
a= "001"
print a.isdigit()
print len(a)
