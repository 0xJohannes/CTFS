#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <arpa/inet.h>

int main(int argc, char* argv[], char* envp[]){
	char *argv[101] = {"~/TESTDIR/Pwnable/input/input", [1 ... 99] = "A", NULL};
	argv['A'] = "\x00";
	argv['B'] = "\x20\x0a\x0d";

	execve("~/TESTDIR/Pwnable/input/input",argv,NULL);
	return 0;
}
