import r2pipe

r2 = r2pipe.open("vuln",flags=['-d'])
r2.cmd('aa')
r2.cmd('dc')
print(r2.cmd("afl"))
r2.quit()
