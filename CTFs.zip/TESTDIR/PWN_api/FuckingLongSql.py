file = open("valod.txts", "r")
cont = file.read()
cont = cont.split(",")
print cont[0].strip().strip("0x").strip(")").strip(";").decode("hex")
d=0
for i in cont:
    d+=1
    if i.find("0x") != -1:
        file = open("new{}".format(d),"w")
        file.write(i.strip().strip("0x").strip(")").strip(";").decode("hex"))
        file.close()
        print "--------------------------"
        print "\n"
