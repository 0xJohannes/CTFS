from base64 import b64decode, b64encode
from Crypto import Random
from Crypto.Cipher import AES
import sys
import time
import binascii
from itertools import cycle, izip
class AESCipher(object):
    def __init__(self):
        self.bs = 32
        random = Random.new()
        self.key = random.read(AES.block_size)
        self.ctr = random.read(AES.block_size)

    def encrypt(self, raw):
        cipher = AES.new(self.key, AES.MODE_CTR, counter=lambda: self.ctr)
        return cipher.encrypt(raw).encode('base64').replace('\n', '')

    def decrypt(self, enc):
        try:
            enc = enc.decode('base64')
        except binascii.Error:
            return None
        cipher = AES.new(self.key, AES.MODE_CTR, counter=lambda: self.ctr)
        return cipher.decrypt(enc)
aes = AESCipher()



def do_encrypt(aes, files):
    return aes.encrypt(files)



flag = "flag_d18b54d63c2b53059758.txt" # The value to encrypt
# print do_encrypt(aes, "flas_5b403007b131955b088a.txt")
# print do_encrypt(aes, flag)
known_plaintext = "flase5b403007b131955b088a" + ".txt"
known_cipher_b64 = '5QgakK0G1omR7Ie+8syAtLJdTtaqA4yFwPHD9rE='
known_cipher = b64decode(known_cipher_b64)
key = ""
for i in xrange(len(known_plaintext)):
    key += chr(ord(known_plaintext[i]) ^ ord(known_cipher[i]))
result = ""
for i in xrange(len(key)):
    result += chr(ord(key[i]) ^ ord(flag[i]))

def xored(data,key):
     xored = ''.join(chr(ord(x) ^ ord(y)) for (x,y) in izip(data, cycle(key)))
     return xored
print b64encode(result)
print b64encode(xored(flag,key))
# print b64encode(encrypt(known_plaintext,key))
# print b64encode(encrypt(flag,key))
