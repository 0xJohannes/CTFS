#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>

#define MAX_NUM_LEN 12
#define HOTSTREAK 3
#define MAX_WINS 16
#define ONE_BILLION 1000000000
#define ROULETTE_SIZE 36
#define ROULETTE_SPINS 128
#define ROULETTE_SLOWS 16
#define NUM_WIN_MSGS 10
#define NUM_LOSE_MSGS 5

int main()
{
    // get seed
    long seed;
    printf("Initial value: ");
    scanf("%d", &seed);
    srand(seed);

    for (int numb = 1; numb < 17; numb++) {
        // do spin rand()
        long spin = (rand() % ROULETTE_SIZE)+1;
        printf("Spin #%d: %d\n", numb, spin);

        // dummy rand() for win message
        long dummy = rand();
    }


    return 0;
}
