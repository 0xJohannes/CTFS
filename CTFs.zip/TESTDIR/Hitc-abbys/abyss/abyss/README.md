* ld.so.2 and libc.so.6 are system libs from Ubuntu 18.04
* ./hypervisor.elf kernel.bin ld.so.2 ./user.elf
