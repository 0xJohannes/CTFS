from Crypto.Util.strxor import strxor
import base64
import random
import string

def enc(data, key):
    key = (key * (len(data) / len(key) + 1))[:len(data)]
    # print key
    return strxor(data, key)

# def padder(data):
#     for i in range(len(data)/11-1):
#         print len(data[i*11:(i+1)*11])


# flag = "hctf{12345678912}"
# print base64.b64encode(enc('qwertyuioplop', flag[5:-1]))
# print enc('@EVFAOBQVA^^B', flag[5:-1])
# print len(enc('qwertyuioplop', flag[5:-1]))


f = open("cipher.txt", "r")
cip =  f.read()
bcip = base64.b64decode(cip)
# print(padder(bcip))
letters="QWERTYUIOPASDFGHJKLZXCVBNMqwertyuiopasdfghjklzxcvbnm1234567890"
# for a in string.printable:
#     key=a*11
#     print enc(base64.b64decode(cip),key)[:1]+"---- {}".format(a)
# nums="0123456789"

# for a in letters:
#     for b in letters:
#         for c in letters:
#             for d in letters:
#                 for e in letters:
#                     for f in letters:
#                         for g in letters:
#                             for h in letters:
#                                 for r in letters:
#                                     for t in letters:
#                                         for q in letters:
#                                             key="{}{}{}{}{}{}{}{}{}{}{}".format(a,b,c,d,e,f,g,h,r,t,q)
#                                             if (enc(base64.b64decode(cip),key)[1:3]+"\n-----{}{}{}{}{}{}{}{}{}{}{}".format(a,b,c,d,e,f,g,h,r,t,q)+"\n").isalpha():
#                                                 print enc(base64.b64decode(cip),key)[1:3]+"\n-----{}{}{}{}{}{}{}{}{}{}{}".format(a,b,c,d,e,f,g,h,r,t,q)+"\n"
print cip[22:25]
for a in letters:
    for b in letters:
        for c in letters:
            key="{}{}{}".format(a,b,c)
            if enc(bcip[:3],key).isalpha() and all(c in string.printable for c in enc(bcip[:3],key)) and all(c in string.printable for c in enc(bcip[11:14],key)) and all(c in string.printable for c in enc(bcip[22:25],key)) and all(c in string.printable for c in enc(bcip[33:36],key)):
                print enc(bcip[:35],key)+"\n-----{}{}{}".format(a,b,c)+"\n"
